#include <stdio.h>

int main(void)
{
	/*This is my first program in C*/

	printf("Hello World");

	printf("I Love C");

	return(0);
}

