#include<stdio.h>

int main(void)
{
	/*This is my second program in C*/

	int age;

	printf("Hi, how old are you?");

	scanf("%d",&age);

	printf("You are %d years old",age);

	return(0);

}

